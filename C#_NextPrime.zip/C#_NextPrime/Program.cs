﻿using System;
using System.Collections.Generic;

namespace C__NextPrime
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            Random r = new Random();
            int n = r.Next(0, 100000);

            System.Console.WriteLine(n);
            System.Console.WriteLine(p.NextPrime(n));
        }

        public int NextPrime(int n)
        {

            while(n % 2 == 0 || n % 3 == 0 || n % 5 == 0 || n % 7 == 0)
            {
                if(n == 2 || n == 3 || n == 5 || n == 7)
                {
                    return n;
                }
                n++;
            }
            return n;
        } 
    }
}
