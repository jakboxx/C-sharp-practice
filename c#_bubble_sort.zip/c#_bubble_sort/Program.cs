﻿using System;

namespace c__bubble_sort
{
    class program
    {
        static void Main(string[] args)
        {
            int[] array = {-5, 6, 8 , 3, 6, 9 , 1};

            program p = new program();

            p.sort(array);
        }

        public void sort(int[] array)
        {
            for(int i = 0; i < array.Length-1; i++)
            {
                for(int j = 0; j < array.Length-i-1;j++)
                {
                    if(array[j] > array[j+1])
                    {
                        int mem = array[j];
                        array[j] = array[j+1];
                        array[j+1] = mem;
                    }
                }
            }

            for(int i = 0; i < array.Length; i++)
            {
                System.Console.WriteLine(array[i]);
            }
        }
    }
}
