﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace drawing_curves
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Width = 800;
            Height = 600;

            SetUp();
        }

        Thread thread;
        Graphics offscreenDC;
        Graphics clientDC;
        Bitmap offscreenbtm;

        void SetUp()
        {
            offscreenbtm = new Bitmap(Width, Height);
            offscreenDC = Graphics.FromImage(offscreenbtm);
            clientDC = CreateGraphics();
            thread = new Thread(Draw);
            thread.IsBackground = true;
            thread.Start();
        }

        void Draw()
        {
            offscreenDC.Clear(Color.White);

            float t = 0f;

            while (true)
            {
                t += .001f;

                if(t > 1f)
                {
                    t = 0f;
                }

                offscreenDC.FillEllipse(new SolidBrush(Color.Red), t * Width, Height - 50f - Mix(SlowStart4(t), SlowStop4(t), 0.5f) * (Height-50f), 15f, 15f);

                clientDC.DrawImage(offscreenbtm, 0, 0);
            }
        }

        float SlowStart4(float t)
        {
            return t * t * t * t * t;
        }

        float SlowStop4(float t)
        {
            return 1f - (1f - t) * (1f - t) * (1f - t) * (1f - t) * (1f - t);
        }

        float Mix(float a, float b, float blend)
        {
            return a + blend * (b - a);
        }
    }
}
