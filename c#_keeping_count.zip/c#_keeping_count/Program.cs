﻿using System;
using System.Collections.Generic;

namespace c__keeping_count
{
    // Given a number, create a function which returns a new number based on the following rules:
    // For each digit, replace it by the number of times that digit appears in the number.

    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();

            Console.Write("Enter a number: ");
            int n = Convert.ToInt32(Console.ReadLine());
            
            Console.Write("Your new number is ");
            Console.WriteLine(p.KeepCount(n));
        }

        public int KeepCount(int n)
        {
            List<int> digits = new List<int>();
            int[] newDigits = new int[10];

            int num = 0;
            int step = 1;

            digits.Add(n%10);

            while(n / 10 > 0)
            {
                n = n / 10;
                digits.Add(n%10);
            }

            foreach(int d in digits)
            {
                for(int i = 10; i > 0; i--)
                {
                    if(d == i)
                    {
                        newDigits[i]++;
                    }
                }
            }

            for(int i = 0; i < digits.Count; i++)
            {
                digits[i] = newDigits[digits[i]];
            }

            for(int i = 0; i < digits.Count; i++)
            {
                num += digits[i] * step;
                step *= 10;
            }

            return num;
        }
    }
}
