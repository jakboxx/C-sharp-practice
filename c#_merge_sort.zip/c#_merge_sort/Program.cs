﻿using System;

namespace merge_sort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[10000];

            Program p = new Program();
            Random r = new Random();

            for(int i = 0; i < array.Length; i++)
            {
                array[i] = r.Next(-101, 101);
            }

            p.MergeSort(array);

           System.Console.WriteLine("done");

            // for(int i = 0; i < array.Length; i++)
            // {
            //     System.Console.WriteLine(array[i]);
            // }
        }

        int[] Merge(int[] a, int[] b, int[] c)
        {
            int i = 0;
            int j = 0;
            int k = 0;

            while(i < a.Length && j < b.Length)
            {
                if(a[i] < b[j])
                {
                    c[k] = a[i];
                    i++;
                }
                else
                {
                    c[k] = b[j];
                    j++;
                }
                k++;
            }

            while(i < a.Length)
            {
                c[k] = a[i];
                i++;
                k++;
            }
            while(j < b.Length)
            {
                c[k] = b[j];
                j++;
                k++;
            }

            a = null;
            b = null;
            
            return c;
        }

        
        int[] MergeSort(int[] array)
        {
            int n = array.Length;

            if(n < 2)
            {
                return array;
            }

            int[] array1 = new int[n/2];
            int[] array2 = new int[n - n/2];

            for(int i = 0; i < n/2; i++)
            {
                array1[i] = array[i];
            }

            for(int i = n/2; i < n; i++)
            {
                array2[i-n/2] = array[i];
            }

            MergeSort(array1);
            MergeSort(array2);
            Merge(array1, array2, array);

            return array;
        }
    }
}
