﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace partical_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Width = 830;
            Height = 600;

            SetUp();
        }

        Thread thread;
        Bitmap offscreenbtm;
        Graphics offscreenDC;
        Graphics clientDC;

        private void SetUp()
        {
            offscreenbtm = new Bitmap(Width, Height);
            offscreenDC = Graphics.FromImage(offscreenbtm);
            clientDC = CreateGraphics();
            thread = new Thread(Draw);
            thread.IsBackground = true;
            thread.Start();
        }

        void Draw()
        {
            List<Partical> particals = new List<Partical>();

            while (true)
            {
                offscreenDC.Clear(Color.White);

                Partical partical = new Partical(new PointF(Width / 2, 100), new SizeF(10f, 10f), 50f, new PointF(Width / 2, 100), 25f, new PointF(Width/2, Height/2));
                particals.Add(partical);

                for(int i = particals.Count-1; i > 0; i--)
                {
                    particals[i].Update();
                    offscreenDC.FillEllipse(particals[i].color, particals[i].position.X, particals[i].position.Y, particals[i].size.Width, particals[i].size.Height);
                    
                    if(particals[i].position.Y > Height || particals[i].life_time < 0f)
                    {
                        particals.RemoveAt(i);
                    }
                }

                clientDC.DrawImage(offscreenbtm, 0, 0);
            }
        }
    }
}
