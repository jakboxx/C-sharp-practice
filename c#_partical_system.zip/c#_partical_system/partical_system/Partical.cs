﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace partical_system
{
    class Partical
    {
        PointF origin, max_position_offset;
        SizeF base_size;
        float max_size_offset;

        public PointF position;
        public SizeF size;
        public float life_time;
        public Brush color;

        PointF velocity;
        PointF accelleration;
        PointF world_center;

        public Partical(PointF origin, SizeF base_size, float life_time, PointF max_position_offset, float max_size_offset, PointF world_center)
        {
            this.origin = origin;
            this.base_size = base_size;
            this.life_time = life_time;
            this.max_position_offset = max_position_offset;
            this.max_size_offset = max_size_offset;
            this.world_center = world_center;

            SetUp();
        }

        void SetUp()
        {
            Random r = new Random();

            position.X = origin.X + (float)r.NextDouble() * 2*max_position_offset.X - max_position_offset.X;
            position.Y = origin.Y + (float)r.NextDouble() * 2*max_position_offset.Y - max_position_offset.Y;

            size.Width = base_size.Width + (float)r.NextDouble() * max_size_offset - max_size_offset;
            size.Height = size.Width;

            color = new SolidBrush(Color.FromArgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255)));
        }

        public void Update()
        {
            if((Control.MouseButtons & MouseButtons.Left) != 0)
            {
                accelleration.X += .2f;
            }
            else if((Control.MouseButtons & MouseButtons.Right) != 0)
            {
                accelleration.X -= .2f;
            }

            if ((Control.ModifierKeys & Keys.Shift) != 0)
            {
                accelleration.X = world_center.X - position.X;
                accelleration.Y = world_center.Y - position.Y;

                if (accelleration.X >= 0)
                {
                    accelleration.X /= accelleration.X;
                }
                else
                {
                    accelleration.X /= accelleration.X;
                    accelleration.X *= -1;
                }

                if (accelleration.Y >= 0)
                {
                    accelleration.Y /= accelleration.Y;
                }
                else
                {
                    accelleration.Y /= accelleration.Y;
                    accelleration.Y *= -1;
                }

                accelleration.X *= .1f;
                accelleration.Y *= .1f;
            }
            else
                accelleration.Y += .1f;

            velocity.X += accelleration.X;
            velocity.Y += accelleration.Y;

            position.X += velocity.X;
            position.Y += velocity.Y;

            accelleration.X = 0f;
            accelleration.Y = 0f;

            life_time -= .1f;
        }
    }
}
