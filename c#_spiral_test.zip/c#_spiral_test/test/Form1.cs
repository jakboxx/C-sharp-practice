﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Width = 800;
            this.Height = 800;

            Form1_Load();
        }

        Thread thread;
        Graphics offScreenDC;
        Bitmap offscreenBmp;
        Graphics clientDC;

        bool drawing = true;

        private void Form1_Load()
        {
            offscreenBmp = new Bitmap(this.Width, this.Height);
            offScreenDC = Graphics.FromImage(offscreenBmp);
            clientDC = this.CreateGraphics();
            thread = new Thread(Draw);
            thread.IsBackground = true;
            thread.Start();
        }


        public void Draw()
        {
            partical[] particals = new partical[20];

            float size = 5;

            for(int i = 0; i < particals.Length; i++)
            {
                particals[i] = new partical(size);
                size += 1f;
            }

            offScreenDC.Clear(Color.White);

            while (drawing) 
            {

                foreach (partical p in particals)
                {
                    p.Move(new PointF(this.Width/2 - p.size, this.Height/2 - p.size));
                    offScreenDC.FillEllipse(p.color, p.bounds);
                }

                clientDC.DrawImage(offscreenBmp, 0,0);
            }
        }
    }

    public class partical 
    {
        public float size;
        public Brush color;
        public RectangleF bounds;

        public partical(float size)
        {
            this.size = size;
        }

        float angle = 0f;
        float radius = 0f;

        public void Move(PointF origin)
        {
            angle += .2f;
            
            if((Control.MouseButtons & MouseButtons.Left) != 0)
            {
                radius -= 1f;
            }
            else
            {
                radius += 1f;
            }

            float x = (float)Math.Cos(angle) * radius;
            float y = (float)Math.Sin(angle) * radius;

            origin.X += x;
            origin.Y += y;

            if(angle > 360)
            {
                angle = 0f;
            }

            this.color = new SolidBrush(RandomColor());

            bounds = new RectangleF(origin.X, origin.Y, size, size);
        }

        Color RandomColor()
        {
            Color color;
            Random r = new Random();
            int pick = r.Next(0, 10);

            switch(pick)
            {
                case 0:
                    color = Color.Crimson;
                    break;
                case 1:
                    color = Color.Red;
                    break;
                case 2:
                    color = Color.Green;
                    break;
                case 3:
                    color = Color.Blue;
                    break;
                case 4:
                    color = Color.Yellow;
                    break;
                case 5:
                    color = Color.Aquamarine;
                    break;
                case 6:
                    color = Color.Pink;
                    break;
                case 7:
                    color = Color.Violet;
                    break;
                case 8:
                    color = Color.Purple;
                    break;
                case 9:
                    color = Color.Cyan;
                    break;
                default:
                    color = Color.White;
                    break;
            }

            return color;
        }
    }
}
